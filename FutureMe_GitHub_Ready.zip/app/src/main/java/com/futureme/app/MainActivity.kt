package com.futureme.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Pink = Color(0xFFFF3C91)
private val Purple = Color(0xFF8C4DFF)
private val Ink = Color(0xFF221436)
private val Cream = Color(0xFFFFF8FE)
private val scenarios = listOf("💸 Богатство", "🌍 Приключения", "🎨 Творчество")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FutureMeApp { message ->
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"; putExtra(Intent.EXTRA_TEXT, message)
            }, "Поделиться FUTURE ME"))
        } }
    }
}

@Composable
private fun FutureMeApp(share: (String) -> Unit) {
    var photo by remember { mutableStateOf<Uri?>(null) }
    var selected by remember { mutableIntStateOf(0) }
    var years by remember { mutableIntStateOf(10) }
    var step by remember { mutableIntStateOf(0) }
    var question by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf<Pair<String, String>>() }
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> photo = uri }
    val background = Brush.verticalGradient(listOf(Color(0xFFFFE7F3), Color(0xFFEDE5FF), Color.White))
    MaterialTheme(colorScheme = lightColorScheme(primary = Purple, secondary = Pink)) {
        Column(Modifier.fillMaxSize().background(background).verticalScroll(rememberScrollState()).padding(22.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Spacer(Modifier.height(8.dp))
            Text("✦ FUTURE ME", color = Purple, fontSize = 19.sp, fontWeight = FontWeight.Black)
            Text(if (step == 0) "Твоё будущее начинается здесь ✨" else "Привет из будущего 🚀", fontSize = 32.sp, lineHeight = 37.sp, fontWeight = FontWeight.Black, color = Ink)
            Text("Фантазийная AI-концепция, не предсказание реальных событий.", color = Ink.copy(alpha = .68f), fontSize = 13.sp)
            if (step == 0) {
                GradientPanel {
                    Text("📸 ТВОЁ СЕЛФИ", color = Color.White, fontWeight = FontWeight.Bold)
                    Text(if (photo == null) "Добавь фотографию для своего профиля" else "Фото выбрано ✓", color = Color.White)
                    Button(onClick = { photoPicker.launch("image/*") }, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Purple)) { Text("Выбрать фото") }
                    Text("Фото остаётся на устройстве и не отправляется на сервер.", fontSize = 11.sp, color = Color.White.copy(alpha = .85f))
                }
                Text("Выбери своё альтернативное будущее", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink)
                scenarios.forEachIndexed { index, item ->
                    val active = selected == index
                    Surface(shape = RoundedCornerShape(22.dp), color = if (active) Color(0xFFFFD4EB) else Color.White, border = BorderStroke(if (active) 2.dp else 1.dp, if (active) Pink else Color(0xFFE8DDEC)), modifier = Modifier.fillMaxWidth().clickable { selected = index }) {
                        Row(Modifier.padding(19.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(item, fontSize = 19.sp, fontWeight = FontWeight.SemiBold, color = Ink)
                            Text(if (active) "●" else "○", color = Pink, fontSize = 22.sp)
                        }
                    }
                }
                Text("Через сколько лет?", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    listOf(5, 10, 20).forEach { value ->
                        FilterChip(selected = years == value, onClick = { years = value }, label = { Text("$value лет") })
                    }
                }
                PrimaryButton("Посмотреть будущее ✨") { messages.clear(); step = 1 }
            } else {
                GradientPanel {
                    Text("🌟 ТЫ ЧЕРЕЗ $years ЛЕТ", fontSize = 22.sp, color = Color.White, fontWeight = FontWeight.Black)
                    Text("Твой сценарий: ${scenarios[selected]}", color = Color.White, fontSize = 17.sp)
                    Text("Это творческая история. Генерация портрета и настоящий AI будут добавлены позже.", color = Color.White.copy(alpha = .9f), fontSize = 13.sp)
                }
                Text("💬 Спроси будущего себя", fontWeight = FontWeight.Bold, fontSize = 21.sp, color = Ink)
                messages.forEach { (who, text) ->
                    Surface(color = if (who == "Ты") Color(0xFFFFD5E9) else Color.White, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(15.dp)) {
                            Text(who, fontWeight = FontWeight.Bold, color = Purple)
                            Spacer(Modifier.height(4.dp))
                            Text(text, color = Ink)
                        }
                    }
                }
                Surface(color = Color.White, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                    BasicTextField(value = question, onValueChange = { question = it }, modifier = Modifier.fillMaxWidth().padding(18.dp), decorationBox = { inner ->
                        if (question.isBlank()) Text("Что бы ты мне посоветовал?", color = Color.Gray)
                        inner()
                    })
                }
                PrimaryButton("Отправить вопрос 💌") {
                    if (question.isNotBlank()) {
                        messages.add("Ты" to question.trim())
                        messages.add("Ты из будущего" to demoReply(selected, years))
                        question = ""
                    }
                }
                OutlinedButton(onClick = { share("Я встретил(а) себя через $years лет! Мой сценарий: ${scenarios[selected]} ✨ #FutureMe") }, modifier = Modifier.fillMaxWidth()) { Text("Поделиться результатом ↗") }
                TextButton(onClick = { step = 0 }) { Text("← Изменить сценарий") }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

private fun demoReply(scenario: Int, years: Int): String {
    val advice = when (scenario) {
        0 -> "Я начал(а) с маленького проекта и научился(ась) управлять деньгами. Главное — создавать ценность, а не гнаться за быстрым успехом."
        1 -> "Я решился(ась) исследовать новые места и встретил(а) удивительных людей. Начни с одного небольшого путешествия."
        else -> "Я каждый день выделял(а) время на творчество. Не жди вдохновения — пробуй, ошибайся и продолжай."
    }
    return "Привет из мира через $years лет! ✨ $advice (Демо-ответ: пока без подключения AI.)"
}

@Composable
private fun GradientPanel(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Pink, Purple)), RoundedCornerShape(26.dp)).padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
}

@Composable
private fun PrimaryButton(text: String, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(18.dp), colors = ButtonDefaults.buttonColors(containerColor = Pink)) {
        Text(text, fontWeight = FontWeight.Bold, fontSize = 16.sp, textAlign = TextAlign.Center)
    }
}
