# FUTURE ME: GitHub APK build

1. Create a **public** GitHub repository named `future-me-android` (free GitHub Actions minutes on public repositories, subject to GitHub policy).
2. Upload the **contents** of this archive to the repository root (not the enclosing folder). GitHub web upload may not accept hidden `.github` directory as a folder; if needed, create `.github/workflows/build-apk.yml` using GitHub's **Add file > Create new file** and paste its content.
3. Open **Actions** > **Build FutureMe APK** > **Run workflow**.
4. After the build succeeds, open its run and download **FutureMe-debug-apk** from Artifacts.
5. Unzip the downloaded artifact to obtain `app-debug.apk`.

Note: This build has not been executed or verified. It creates a debug APK for testing, not a Play Store release. No AI image generation or live AI chat is implemented.
