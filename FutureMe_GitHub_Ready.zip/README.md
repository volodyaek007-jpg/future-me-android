# FUTURE ME — Android MVP

Android app prototype in Kotlin / Jetpack Compose. The UI is in Russian.

## Included
- Bright social-style gradient interface
- Local photo selection (not uploaded or displayed yet)
- 3 future scenarios and 5/10/20-year choice
- Offline scripted chat (clearly labeled demo)
- Android text sharing via system share sheet

## Build APK
1. Install Android Studio with Android SDK 35 and JDK 17+.
2. Open this `FutureMe` folder as a project.
3. Let Gradle sync and download dependencies (internet required).
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Find APK at `app/build/outputs/apk/debug/app-debug.apk`.

You can also run `gradle assembleDebug` with a compatible Gradle installation (8.9 recommended) and Android SDK configured.

## Important limitations
This is an offline prototype, NOT an AI image generator. It does not generate future portraits, and the chat is scripted. Selected photos are only represented by a selected-state label; they are not rendered or uploaded. Sharing is text only. No backend, payment, authentication, analytics, or app-store assets are included. No APK was compiled in this environment because Android SDK / Gradle are not available.

## Next iteration
Add local image preview, consent/deletion UX, secure backend, image generation API, real chat, shareable image cards, event analytics and cost controls.
